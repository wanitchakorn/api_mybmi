// ignore: file_names
import 'package:flutter/material.dart';
import 'package:api_mybmi/BMImodel.dart';

// TODO: import BMRModel.dart
import 'BMImodel.dart';

// ignore: must_be_immutable
class BMIresultPage extends StatefulWidget {
  // ignore: use_key_in_widget_constructors
  BMIresultPage({Key? key, required this.bmidata, required this.interpretation});
  // TODO: add new parameter for storing bmrdata from caller

  // TODO: declare parameter to keep bmrdata
  final Bmidata  bmidata;
  final String interpretation;

  @override
  State<BMIresultPage> createState() => _BMIresultPageState();
}

class _BMIresultPageState extends State<BMIresultPage> {
  late var _weight, _height, _bmi;
  late String _interpretation;

  @override
  void initState() {
    super.initState();
    // TODO: initialize variables for displaying on listtile
    // move bmrdata into variables for showing ...here...
    _weight = widget.bmidata.weight!;
    _height = widget.bmidata.height!;
    _bmi = widget.bmidata.bmi!;
    _interpretation = widget.interpretation;
  }

  String getInterpretation() {
    if (_bmi < 18.5) {
      return 'You are Underweight.';
    } else if (_bmi >= 18.5 && _bmi < 24.9) {
      return 'You have a Normal Weight (Healthy).';
    } else if (_bmi >= 24.9 && _bmi < 29.9) {
      return 'You are Overweight.';
    } else {
      return 'You are Obese.';
    }
  }

  @override
  Widget build(BuildContext context) {
    _interpretation = getInterpretation();
    return Scaffold(
        appBar: AppBar(
          title: const Text('Result of Your BMR'),
        ),
        body: 
      //   Center(
      // child: Container(
      //   child: GridView.count(
      //     padding: const EdgeInsets.all(15.0),
      //     crossAxisSpacing: 10,
      //     mainAxisSpacing: 10,
      //     crossAxisCount: 2,
      //     scrollDirection: Axis.vertical, 
      //     children: [
      //       Card(
      //         color: Colors.pink[200],
      //         child: Center(
      //           child: ListTile(
      //                 title: Text('$_weight',style: TextStyle(color: Colors.black, fontSize: 50)),
      //                 subtitle: Text('Weight'),
      //                 leading: Icon(Icons.star)
      //                 ),
      //         ),),
      //       Card(
      //         color: Colors.pink[100],
      //         child: Center(
      //           child: ListTile(
      //                 title: Text('$_height',style: TextStyle(color: Colors.black, fontSize: 50)),
      //                 subtitle: Text('Height',style: TextStyle(fontSize: 16)),
      //                 leading: Icon(Icons.star)
      //                 ),
      //         ),),
      //       Card(
      //         color: Colors.purple[200],
      //         child: ListTile(
      //               title: Text('$_bmi',style: TextStyle(color: Colors.black, fontSize: 20)),
      //               subtitle: Text('BMI Value',style: TextStyle(fontSize: 22)),
      //               leading: Icon(Icons.star)
      //               ),),
      //       ],
      //   ),
      //   ),
      //   )
        LayoutBuilder(
        builder: (context, constraints) => SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: constraints.maxHeight * .6 + 70, //70 for bottom
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      bottom: 70, // to shift little up
                      left: 0,
                      right: 0,
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.lightBlue,
                          borderRadius: BorderRadius.vertical(
                            bottom: Radius.circular(20),
                          ),
                        ),
                        width: constraints.maxWidth,
                        height: constraints.maxHeight * 0.6,
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(30.0),
                          child: ListTile(
                            title: Text('$_weight kg.',style: TextStyle(color: Colors.black, fontSize: 40)),
                            subtitle: Text('Weight',style: TextStyle(fontSize: 20)),
                            leading: Icon(Icons.height_rounded, size: 70,)),),
                        Padding(
                          padding: EdgeInsets.all(30.0),
                          child: ListTile(
                            title: Text('$_height cm.',style: TextStyle(color: Colors.black, fontSize: 40)),
                            subtitle: Text('Height',style: TextStyle(fontSize: 20)),
                            leading: Icon(Icons.line_weight_rounded, size: 70,)),),
                    ],),),
                    ),
                    Positioned(
                      top: constraints.maxHeight * .4,
                      height: 300,
                      left: 30,
                      right: 30,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(30),
                        child: Column(
                          children: [
                            Card(
                              child: Container(
                                color: Colors.pinkAccent,
                              child: ListTile(
                                contentPadding: EdgeInsets.all(20),
                                title: Text('$_bmi',style: TextStyle(color: Colors.white, fontSize: 30)),
                                ),
                              ),
                            ),
                            Card(
                              child: Container(
                                color: Colors.amber,
                              child: ListTile(
                                contentPadding: EdgeInsets.all(20),
                                title: Text('$_interpretation',style: TextStyle(color: Colors.black, fontSize: 24)),
                                leading:Icon(Icons.check_circle, size: 30,),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    // Positioned(
                    //   bottom: 0,
                    //   left: 20,
                    //   right: 20,
                    //   child: Column(
                    //     children: [ Card(
                    //       color: Colors.white,
                    //       child: Padding(
                    //       padding: EdgeInsets.all(16.0),
                    //         child: Image.asset("assets/rsbmi.jpg",),),
                    //   ),],),
                    // ),
                  ],
                ),
              ),
              // Expanded(
              //       child: ElevatedButton(
              //         style: ButtonStyle(
              //           backgroundColor:
              //               MaterialStateProperty.all<Color>(Colors.red),
              //         ),
              //         child: const Text('Close'),
              //         onPressed: () {
              //           Navigator.pop(context);
              //         },
              //       ),
              //     ),
            ],
          ),
        ),),
        // ListView(
        //   children: [
        //     ListTile(
        //       title: const Text('Weight:'),
        //       subtitle: Text('$_weight'),
        //       leading: const Icon(Icons.scale_outlined),
        //     ),
        //     ListTile(
        //       title: const Text('Height:'),
        //       subtitle: Text('$_height'),
        //       leading: const Icon(Icons.arrow_upward),
        //     ),
            
        //     ListTile(
        //       title: const Text('BMI Value:'),
        //       subtitle: Text(
        //         '$_bmi',
        //         style: TextStyle(color: Colors.deepOrange),
        //       ),
        //       leading: const Icon(Icons.timeline_rounded),
        //     ),
        //     // ListTile(
        //     //   title: const Text('เกณฑ์:'),
        //     //   subtitle: Text('$_interpretation'),
        //     //   leading: const Icon(Icons.timer),
        //     // ),
        //     // ListTile(
        //     //   title: const Text('Gender:'),
        //     //   subtitle: Text('$_gender'),
        //     //   leading: const Icon(Icons.person_outlined),
        //     // ),
        //   ],
        // )
      );
  }
}
